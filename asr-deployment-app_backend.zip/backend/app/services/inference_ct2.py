import logging
import time
import os
import sys

import torch

from app.core.config import settings
from faster_whisper import WhisperModel
from .postprocess_text import postprocess_text, load_sec_dict
from .audio_utils import load_audio, compute_duration

logger = logging.getLogger(__name__)

CPR_MODEL_PATH = settings.CPR_MODEL_PATH
CPR_VOCAB_PATH = os.path.join(CPR_MODEL_PATH, "vocabulary")
sys.path.append(os.path.join(CPR_MODEL_PATH))



_model = None
_backend = None
_cpr_model = None

_vad_utils = None
_vad_model = None

def _ensure_vad_model():
    global _vad_model, _vad_utils
    if _vad_model is None:
        _vad_model, _vad_utils = torch.hub.load(
            # repo_or_dir="snakers4/silero-vad",
            repo_or_dir=settings.VAD_MODEL_PATH,
            model="silero_vad",
            source="local",
            force_reload=False
        )


def _load_cpr_model():
    logger.info("Loading CPR model...")
    from gec_model import GecBERTModel
    model = GecBERTModel(
        vocab_path=CPR_VOCAB_PATH,
        model_paths=CPR_MODEL_PATH,
        split_chunk=True
    )
    return model

def _ensure_cpr_model():
    global _cpr_model
    if _cpr_model is None:  
        _cpr_model = _load_cpr_model()

def _load_faster_whisper_model():
    """
    Load faster-whisper model.
    """
    try:
        model_path = settings.WHISPER_CT2_MODEL_PATH
        logger.info("Loading faster-whisper model: %s", model_path)


        model = WhisperModel(
            model_path,
            device=settings.DEVICE,
            # device="cpu",
            compute_type="float16" if settings.DEVICE == "cuda" else "int8",
            # compute_type="int8"
        )
        return model
    except Exception as e:
        logger.exception("Failed to load faster-whisper model: %s", e)
        raise


def _ensure_whisper_model():
    global _model, _backend
    if _model is not None:
        return
    _model = _load_faster_whisper_model()
    _backend = "faster-whisper"


_sec_dict = None

def _ensure_sec_model():

    global _sec_dict

    if _sec_dict is None:
        logger.info("Loading SEC model...")
        sec_dict_path = os.path.join(settings.SEC_MODEL_PATH, "sec_dict.txt")
        _sec_dict = load_sec_dict(sec_dict_path)

def has_speech(audio_array, sr, min_speech_duration_ms=250):
    """
    Check if the audio has speech.
    audio_array: numpy 1D or torch.Tensor 1D
    """
    get_speech_timestamps = _vad_utils[0]

    if not isinstance(audio_array, torch.Tensor):
        wav_tensor = torch.from_numpy(audio_array).float()
    else:
        wav_tensor = audio_array.float()

    wav_tensor = wav_tensor.squeeze()

    # VAD
    speech_timestamps = get_speech_timestamps(
        wav_tensor,
        _vad_model,
        sampling_rate=sr,
        min_speech_duration_ms=min_speech_duration_ms
    )

    return len(speech_timestamps) > 0


def asr_infer(
    audio_path: str,
    do_enhance_speech: bool = False,
    do_postprocess_text: bool = True,
    milliseconds: bool = True
) -> dict:
    """
    Run inference with faster-whisper.
    Return dict {"text": ..., "duration": ..., "processing_time": ...}
    Duration is in seconds or milliseconds depending on the flag.
    """
    _ensure_vad_model()
    _ensure_whisper_model()
    _ensure_cpr_model()
    _ensure_sec_model()

    if _backend == "faster-whisper":
        logger.info("Running faster-whisper inference on %s", audio_path)

        total_processing_start = time.time()

        audio_array, sr = load_audio(audio_path)
        duration = compute_duration(audio_array, sr, milliseconds=milliseconds)

        # Check if audio has speech
        if not has_speech(audio_array, sr):
            total_processing_time = time.time() - total_processing_start
            if milliseconds:
                total_processing_time = round(total_processing_time * 1000, 3)
            else:
                total_processing_time = round(total_processing_time, 3)
            logger.info("No speech detected in audio: %s", audio_path)
            
            return {
                "text": "",
                "duration": duration,
                "total_processing_time": total_processing_time,
                "speech_enhancement_time": None,
                "asr_time": None,
                "text_postprocessing_time": None,
            }

        # Transcribe
        asr_start = time.time()
        segments, info = _model.transcribe(audio_path, beam_size=5, language="vi")
        raw_text = " ".join([seg.text for seg in segments]).strip()
        asr_time = time.time() - asr_start
        if milliseconds:
            asr_time = round(asr_time * 1000, 3)
        else:
            asr_time = round(asr_time, 3)

        logger.info("Raw Transcript: %s", raw_text)

        # Speech Enhancement
        if do_enhance_speech:
            pass

        # Postprocess Text
        if do_postprocess_text:
            text_postprocessing_output = postprocess_text(raw_text, _sec_dict, _cpr_model)
            postprocessed_text = text_postprocessing_output["text"]
            text_postprocessing_time = text_postprocessing_output["text_postprocessing_time"]

            if isinstance(postprocessed_text, list):
                postprocessed_text = postprocessed_text[0]
            text = postprocessed_text
            logger.info("Postprocessed Transcript: %s", text)
        else:
            text = raw_text
            text_postprocessing_time = None

        # Total Processing Time
        if text_postprocessing_time:
            if milliseconds:
                text_postprocessing_time = round(text_postprocessing_time * 1000, 3)
            else:
                text_postprocessing_time = round(text_postprocessing_time, 3)
            

        total_processing_time = time.time() - total_processing_start
        if milliseconds:
            total_processing_time = round(total_processing_time * 1000, 3)
        else:
            total_processing_time = round(total_processing_time, 3)

        if milliseconds:
            logger.info(
                f"Transcript: %s | Duration: %s ms | ASR Time: %s ms | Text Postprocessing Time: %s ms | Total Processing Time: %s ms",
                text,
                duration,
                asr_time,
                text_postprocessing_time,
                total_processing_time,
            )
        else:
            logger.info(
                f"Transcript: %s | Duration: %s s | ASR Time: %s s | Text Postprocessing Time: %s s | Total Processing Time: %s s",
                text,
                duration,
                asr_time,
                text_postprocessing_time,
                total_processing_time,
            )

        return {
            "text": text,
            "duration": duration,
            "total_processing_time": total_processing_time,
            "speech_enhancement_time": None,
            "asr_time": asr_time,
            "text_postprocessing_time": text_postprocessing_time,
        }

    else:
        return {
            "text": "",
            "duration": None,
            "total_processing_time": None,
            "speech_enhancement_time": None,
            "asr_time": None,
            "text_postprocessing_time": None,
        }

