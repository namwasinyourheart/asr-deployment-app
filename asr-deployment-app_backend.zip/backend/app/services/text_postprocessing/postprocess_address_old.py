# app/services/postprocess_address.py

import os
from transformers import AutoTokenizer, AutoModelForTokenClassification, pipeline
from rapidfuzz import process, fuzz
import logging

logging.basicConfig(
    level=logging.INFO,          # mức log từ INFO trở lên sẽ được in
    format="%(asctime)s [%(levelname)s] %(message)s"
)

logger = logging.getLogger(__name__)

# --- NER model ---
_tokenizer = None
_model = None
_nlp = None

def _load_ner_model():
    global _tokenizer, _model, _nlp
    logger.info("Loading Vietnamese NER model...")
    _tokenizer = AutoTokenizer.from_pretrained("NlpHUST/ner-vietnamese-electra-base")
    _model = AutoModelForTokenClassification.from_pretrained("NlpHUST/ner-vietnamese-electra-base")
    _nlp = pipeline(
        "ner",
        model=_model,
        tokenizer=_tokenizer,
        aggregation_strategy="simple"
    )

def _ensure_ner_model():
    global _nlp
    if _nlp is None:
        _load_ner_model()


# --- Load place lists as global variables ---
_wards = None
_districts = None
_provinces = None

def _load_places_file(path):
    with open(path, "r", encoding="utf-8") as f:
        return [line.strip() for line in f if line.strip()]

def ensure_places_loaded(wards_file=None, districts_file=None, provinces_file=None):
    """
    Load từng file nếu danh sách tương ứng chưa được load và file được cung cấp.
    """
    global _wards, _districts, _provinces

    if _wards is None and wards_file is not None:
        _wards = _load_places_file(wards_file)
        logger.info(f"Loaded {len(_wards)} wards from {wards_file}")

    if _districts is None and districts_file is not None:
        _districts = _load_places_file(districts_file)
        logger.info(f"Loaded {len(_districts)} districts from {districts_file}")

    if _provinces is None and provinces_file is not None:
        _provinces = _load_places_file(provinces_file)
        logger.info(f"Loaded {len(_provinces)} provinces from {provinces_file}")


# --- Fuzzy match ---
def _correct_locations_3level(ner_results, threshold=80):
    global _wards, _districts, _provinces

    # _wards = [ward.lower() for ward in _wards]
    # _districts = [district.lower() for district in _districts]
    # _provinces = [province.lower() for province in _provinces]

    corrected = []
    for ent in ner_results:
        if ent.get("entity_group") in ["LOC", "LOCATION"]:
            loc = ent["word"]
            best_match = None
            best_score = 0
            level = None
            for name_list, lvl in zip([_wards, _districts, _provinces], ['ward','district','province']):
                if name_list:
                    match, score, _ = process.extractOne(loc, name_list, scorer=fuzz.WRatio)
                    if score > best_score:
                        best_score = score
                        best_match = match
                        level = lvl
            if best_score >= threshold:
                corrected.append((loc, best_match, level, best_score))
            else:
                corrected.append((loc, None, None, best_score))
    return corrected

# --- Public API ---
def postprocess_address(text, threshold=40):
    """
    Nhận ASR transcript text, detect và correct địa điểm (3 cấp)
    Trả về list tuples: (original_text, corrected_text, level, score)
    """
    _ensure_ner_model()
    ner_results = _nlp(text)
    return _correct_locations_3level(ner_results, threshold=threshold)

def load_places_from_file(path):
    with open(path, "r", encoding="utf-8") as f:
        places = [line.strip() for line in f if line.strip()]
    return places

# wards = load_places_from_file("/home/nampv1/projects/asr/asr_ft/postprocessing/address/wards.txt")
# districts = load_places_from_file("/home/nampv1/projects/asr/asr_ft/postprocessing/address/districts.txt")
# provinces = load_places_from_file("/home/nampv1/projects/asr/asr_ft/postprocessing/address/provinces.txt")

# wards_file = "/home/nampv1/projects/asr/asr_ft/postprocessing/address/wards.txt"
wards_file = None
districts_file = "/home/nampv1/projects/asr/asr_ft/postprocessing/address/districts.txt"
districts_file = None
provinces_file = "/home/nampv1/projects/asr/asr_ft/postprocessing/address/provinces.txt"

# print(_provinces)

ensure_places_loaded(wards_file, districts_file, provinces_file)

# print(_provinces)


# --- Demo ---
if __name__ == "__main__":
    # wards_file = "/home/nampv1/projects/asr/asr_ft/postprocessing/address/wards.txt"
    # districts_file = "/home/nampv1/projects/asr/asr_ft/postprocessing/address/districts.txt"
    provinces_file = "/home/nampv1/projects/asr/asr_ft/postprocessing/address/provinces.txt"

    # ensure_places_loaded(wards_file, districts_file, provinces_file)

    sample_text = "Bưu gửi đến thôn Rừng Dông, xã Phướt Mỹ, thành phố Phan Rang-Tháp Chàm, tỉnh Ninh Thuật."
    results = postprocess_address(sample_text)

    print("Input:", sample_text)
    print("Detected & corrected locations:")
    for orig, corr, lvl, score in results:
        print(f"  {orig} → {corr} (level={lvl}, score={score})")